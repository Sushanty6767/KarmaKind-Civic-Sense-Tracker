package com.karmakind.dao;

import com.karmakind.model.Task;
import java.util.List;

public interface TaskDAO {
    void init() throws Exception;
    void saveTask(Task t) throws Exception;
    void updateTask(Task t) throws Exception;
    void deleteTask(String id) throws Exception;
    Task getTask(String id) throws Exception;
    List<Task> getAllTasks() throws Exception;
}
