package com.karmakind.dao;

import com.karmakind.model.Task;
import com.karmakind.model.BehaviourTask;
import com.karmakind.model.HabitTask;

import java.sql.*;
import java.util.*;

public class TaskDAOImpl implements TaskDAO {
    private String jdbcUrl;
    private String user;
    private String pass;

    public TaskDAOImpl(String jdbcUrl, String user, String pass) {
        this.jdbcUrl = jdbcUrl;
        this.user = user;
        this.pass = pass;
    }

    @Override
    public void init() throws Exception {
        try (Connection c = getConnection()) {
            // ensure table exists; for H2 during tests this will create table
            String sql = "CREATE TABLE IF NOT EXISTS tasks (" +
                    "id VARCHAR(100) PRIMARY KEY, " +
                    "title VARCHAR(255), " +
                    "description CLOB, " +
                    "completed BOOLEAN, " +
                    "created_on DATE, " +
                    "base_karma INT, " +
                    "tag VARCHAR(100), " +
                    "type VARCHAR(50), " +
                    "difficulty INT, " +
                    "streak INT" +
                    ")";
            try (Statement s = c.createStatement()) {
                s.execute(sql);
            }
        }
    }

    private Connection getConnection() throws SQLException {
        if (user == null) return DriverManager.getConnection(jdbcUrl);
        return DriverManager.getConnection(jdbcUrl, user, pass);
    }

    @Override
    public void saveTask(Task t) throws Exception {
        String sql = "INSERT INTO tasks (id,title,description,completed,created_on,base_karma,tag,type,difficulty,streak) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, t.getId());
            ps.setString(2, t.getTitle());
            ps.setString(3, t.getDescription());
            ps.setBoolean(4, t.isCompleted());
            ps.setDate(5, java.sql.Date.valueOf(t.getCreatedOn()));
            ps.setInt(6, t.getBaseKarma());
            ps.setString(7, t.getTag());
            if (t instanceof BehaviourTask) {
                BehaviourTask b = (BehaviourTask) t;
                ps.setString(8, "behaviour");
                ps.setInt(9, b.getDifficulty());
                ps.setInt(10, 0);
            } else if (t instanceof HabitTask) {
                HabitTask h = (HabitTask) t;
                ps.setString(8, "habit");
                ps.setNull(9, Types.INTEGER);
                ps.setInt(10, h.getStreakDays());
            } else {
                ps.setString(8, "unknown");
                ps.setNull(9, Types.INTEGER);
                ps.setInt(10, 0);
            }
            ps.executeUpdate();
        }
    }

    @Override
    public void updateTask(Task t) throws Exception {
        String sql = "UPDATE tasks SET title=?, description=?, completed=?, base_karma=?, tag=?, type=?, difficulty=?, streak=? WHERE id=?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, t.getTitle());
            ps.setString(2, t.getDescription());
            ps.setBoolean(3, t.isCompleted());
            ps.setInt(4, t.getBaseKarma());
            ps.setString(5, t.getTag());
            if (t instanceof BehaviourTask) {
                BehaviourTask b = (BehaviourTask) t;
                ps.setString(6, "behaviour");
                ps.setInt(7, b.getDifficulty());
                ps.setInt(8, 0);
            } else if (t instanceof HabitTask) {
                HabitTask h = (HabitTask) t;
                ps.setString(6, "habit");
                ps.setNull(7, Types.INTEGER);
                ps.setInt(8, h.getStreakDays());
            } else {
                ps.setString(6, "unknown");
                ps.setNull(7, Types.INTEGER);
                ps.setInt(8, 0);
            }
            ps.setString(9, t.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void deleteTask(String id) throws Exception {
        String sql = "DELETE FROM tasks WHERE id=?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Task getTask(String id) throws Exception {
        String sql = "SELECT * FROM tasks WHERE id=?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rowToTask(rs);
            }
        }
        return null;
    }

    @Override
    public List<Task> getAllTasks() throws Exception {
        List<Task> list = new ArrayList<>();
        String sql = "SELECT * FROM tasks";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(rowToTask(rs));
            }
        }
        return list;
    }

    private Task rowToTask(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String title = rs.getString("title");
        String desc = rs.getString("description");
        boolean completed = rs.getBoolean("completed");
        java.sql.Date d = rs.getDate("created_on");
        int base = rs.getInt("base_karma");
        String tag = rs.getString("tag");
        String type = rs.getString("type");
        int difficulty = rs.getInt("difficulty");
        int streak = rs.getInt("streak");

        Task t;
        if ("behaviour".equalsIgnoreCase(type)) {
            BehaviourTask b = new BehaviourTask(id, title, desc, base, tag, difficulty==0?1:difficulty);
            t = b;
        } else if ("habit".equalsIgnoreCase(type)) {
            HabitTask h = new HabitTask(id, title, desc, base, tag);
            // set streak via reflection-style setter
            try { 
                java.lang.reflect.Method m = h.getClass().getMethod("incrementStreak");
                for (int i=0;i<streak;i++) h.incrementStreak();
            } catch (Exception ex) {}
            t = h;
        } else {
            // fallback to habit
            t = new HabitTask(id, title, desc, base, tag);
        }
        t.setCompleted(completed);
        return t;
    }
}
