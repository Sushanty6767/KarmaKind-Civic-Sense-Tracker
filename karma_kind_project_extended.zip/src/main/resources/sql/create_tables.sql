-- SQL schema for KarmaKind tasks
CREATE TABLE IF NOT EXISTS tasks (
  id VARCHAR(100) PRIMARY KEY,
  title VARCHAR(255),
  description TEXT,
  completed BOOLEAN,
  created_on DATE,
  base_karma INT,
  tag VARCHAR(100),
  type VARCHAR(50),
  difficulty INT,
  streak INT
);
