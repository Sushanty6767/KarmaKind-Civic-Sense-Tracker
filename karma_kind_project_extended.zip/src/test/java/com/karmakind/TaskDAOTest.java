package com.karmakind;

import com.karmakind.dao.TaskDAO;
import com.karmakind.dao.TaskDAOImpl;
import com.karmakind.model.HabitTask;
import com.karmakind.model.Task;
import org.junit.jupiter.api.*;

import java.util.List;

public class TaskDAOTest {

    private static TaskDAO dao;

    @BeforeAll
    public static void setup() throws Exception {
        String url = "jdbc:h2:mem:karmadb;DB_CLOSE_DELAY=-1";
        dao = new TaskDAOImpl(url, null, null);
        dao.init();
    }

    @Test
    public void testSaveAndGet() throws Exception {
        HabitTask h = new HabitTask("t1","Drink Water","Drink 8 glasses",10,"health");
        dao.saveTask(h);
        Task t = dao.getTask("t1");
        Assertions.assertNotNull(t);
        Assertions.assertEquals("Drink Water", t.getTitle());
    }

    @Test
    public void testUpdateAndDelete() throws Exception {
        HabitTask h = new HabitTask("t2","Walk","Morning walk",5,"fitness");
        dao.saveTask(h);
        h.setTitle("Walk Updated");
        dao.updateTask(h);
        Task t = dao.getTask("t2");
        Assertions.assertEquals("Walk Updated", t.getTitle());
        dao.deleteTask("t2");
        Task deleted = dao.getTask("t2");
        Assertions.assertNull(deleted);
    }

    @Test
    public void testGetAll() throws Exception {
        HabitTask h = new HabitTask("t3","Read","Read a book",8,"study");
        dao.saveTask(h);
        List<Task> all = dao.getAllTasks();
        Assertions.assertTrue(all.size()>=1);
    }
}
