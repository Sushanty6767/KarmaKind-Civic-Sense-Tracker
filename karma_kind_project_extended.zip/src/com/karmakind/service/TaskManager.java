package com.karmakind.service;

import com.karmakind.model.Task;
import java.util.List;

public interface TaskManager {
    void addTask(Task t) throws com.karmakind.exceptions.TaskValidationException;
    void updateTask(Task t) throws com.karmakind.exceptions.TaskValidationException;
    void deleteTask(String id);
    Task getTask(String id);
    List<Task> getAllTasks();
    int getTotalKarma();
    void markCompleted(String id);
}
