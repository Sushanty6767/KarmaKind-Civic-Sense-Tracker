package com.karmakind.service;

import com.karmakind.model.Task;
import com.karmakind.exceptions.TaskValidationException;

import java.io.*;
import java.util.*;

public class FileTaskManager implements TaskManager {
    private List<Task> tasks = new ArrayList<>();
    private File storageFile;

    public FileTaskManager(File storageFile) {
        this.storageFile = storageFile;
        load();
    }

    @Override
    public void addTask(Task t) throws TaskValidationException {
        validate(t);
        tasks.add(t);
        save();
    }

    @Override
    public void updateTask(Task t) throws TaskValidationException {
        validate(t);
        for (int i=0;i<tasks.size();i++){
            if (tasks.get(i).getId().equals(t.getId())) {
                tasks.set(i, t);
                save();
                return;
            }
        }
        throw new TaskValidationException("Task not found for update");
    }

    @Override
    public void deleteTask(String id) {
        tasks.removeIf(x -> x.getId().equals(id));
        save();
    }

    @Override
    public Task getTask(String id) {
        return tasks.stream().filter(x->x.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks);
    }

    @Override
    public int getTotalKarma() {
        int sum = 0;
        for (Task t : tasks) {
            if (t.isCompleted()) sum += t.calculateKarma();
        }
        return sum;
    }

    @Override
    public void markCompleted(String id) {
        Task t = getTask(id);
        if (t != null) {
            t.setCompleted(true);
            if (t instanceof com.karmakind.model.HabitTask) {
                ((com.karmakind.model.HabitTask)t).incrementStreak();
            }
            save();
        }
    }

    private void validate(Task t) throws TaskValidationException {
        if (t.getTitle() == null || t.getTitle().trim().isEmpty()) {
            throw new TaskValidationException("Title cannot be empty");
        }
    }

    private void save() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(storageFile))) {
            oos.writeObject(tasks);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private void load() {
        if (!storageFile.exists()) return;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(storageFile))) {
            Object obj = ois.readObject();
            if (obj instanceof List) {
                tasks = (List<Task>) obj;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
