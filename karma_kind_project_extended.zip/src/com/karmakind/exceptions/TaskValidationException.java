package com.karmakind.exceptions;

public class TaskValidationException extends Exception {
    public TaskValidationException(String msg) {
        super(msg);
    }
}
