package com.karmakind.model;

public class BehaviourTask extends Task {
    private static final long serialVersionUID = 1L;
    private int difficulty; // 1..5

    public BehaviourTask(String id, String title, String description, int baseKarma, String tag, int difficulty) {
        super(id, title, description, baseKarma, tag);
        this.difficulty = Math.max(1, Math.min(5, difficulty));
    }

    public int getDifficulty() { return difficulty; }
    public void setDifficulty(int d) { difficulty = Math.max(1, Math.min(5, d)); }

    @Override
    public int calculateKarma() {
        // scale karma by difficulty
        return getBaseKarma() * difficulty;
    }
}
