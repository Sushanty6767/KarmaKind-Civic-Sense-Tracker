package com.karmakind.model;

public class HabitTask extends Task {
    private static final long serialVersionUID = 1L;
    private int streakDays;

    public HabitTask(String id, String title, String description, int baseKarma, String tag) {
        super(id, title, description, baseKarma, tag);
        this.streakDays = 0;
    }

    public void incrementStreak() {
        streakDays++;
    }

    public void resetStreak() {
        streakDays = 0;
    }

    public int getStreakDays() { return streakDays; }

    @Override
    public int calculateKarma() {
        // reward extra for streaks
        return getBaseKarma() + (streakDays * 2);
    }
}
