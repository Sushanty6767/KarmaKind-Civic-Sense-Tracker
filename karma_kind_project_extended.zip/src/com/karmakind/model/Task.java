package com.karmakind.model;

import java.io.Serializable;
import java.time.LocalDate;

public abstract class Task implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String title;
    private String description;
    private boolean completed;
    private LocalDate createdOn;
    private int baseKarma;
    private String tag;

    public Task(String id, String title, String description, int baseKarma, String tag) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.baseKarma = baseKarma;
        this.tag = tag;
        this.createdOn = LocalDate.now();
        this.completed = false;
    }

    public abstract int calculateKarma();

    // Getters and setters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public LocalDate getCreatedOn() { return createdOn; }
    public int getBaseKarma() { return baseKarma; }
    public String getTag() { return tag; }
    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setBaseKarma(int karma) { this.baseKarma = karma; }
    public void setTag(String tag) { this.tag = tag; }
}
