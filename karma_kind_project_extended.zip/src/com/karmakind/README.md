# KarmaKind - Civic Sense Tracker (Simple Java Swing Project)

This simplified Java Swing project implements the core concepts from the uploaded PPT (KarmaKind – Civic Sense Tracker). It focuses on essential features:
- Task and Habit tracking (Task, HabitTask, BehaviourTask)
- Karma calculation with polymorphism
- TaskManager interface and File-based persistence (serialization)
- Simple Java Swing GUI to add, complete, and delete tasks
- Basic validations and custom exception

## How to run

1. Ensure you have Java 8+ installed.
2. Compile:
   ```bash
   javac -d out $(find . -name "*.java")
   ```
   Or compile using an IDE (IntelliJ/Eclipse) by importing the `src` folder.
3. Run:
   ```bash
   java -cp out com.karmakind.App
   ```

Data is stored in `karmakind_tasks.dat` in the user's home directory.

## Notes
- This project uses Java serialization for simplicity. For production, replace with JDBC/MySQL as described in the PPT.
- The code intentionally demonstrates OOP principles: inheritance, polymorphism, encapsulation, interfaces, and custom exceptions.

Refer to the original PPT for architecture and feature ideas. (Source: uploaded PPT file pages). 
