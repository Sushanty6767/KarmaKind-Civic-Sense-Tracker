#!/bin/bash
# Optional script to compile and package the project
mkdir -p out
javac -d out $(find src -name "*.java")
cd out
jar cfe karmakind.jar com.karmakind.App com
cd ..
zip -r karma_kind_project.zip src README.md
