package com.karmakind.ui;

import com.karmakind.model.*;
import com.karmakind.service.*;
import com.karmakind.exceptions.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.List;
import java.util.UUID;

public class MainFrame extends JFrame {
    private FileTaskManager manager;
    private DefaultListModel<String> listModel;
    private JList<String> taskList;
    private JLabel karmaLabel, streakLabel;

    public MainFrame() {
        setTitle("KarmaKind - Civic Sense Tracker");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        File storage = new File(System.getProperty("user.home"), "karmakind_tasks.dat");
        manager = new FileTaskManager(storage);

        JPanel main = new JPanel(new BorderLayout(10,10));
        main.setBorder(new EmptyBorder(10,10,10,10));
        setContentPane(main);

        // Left: task list
        listModel = new DefaultListModel<>();
        taskList = new JList<>(listModel);
        JScrollPane sc = new JScrollPane(taskList);
        sc.setPreferredSize(new Dimension(320, 0));
        main.add(sc, BorderLayout.WEST);

        // Right: details & controls
        JPanel right = new JPanel(new BorderLayout(10,10));
        main.add(right, BorderLayout.CENTER);

        JPanel inputs = new JPanel(new GridLayout(0,1,5,5));
        JTextField titleF = new JTextField();
        JTextField tagF = new JTextField();
        JTextArea descA = new JTextArea(4,20);
        JComboBox<String> typeCb = new JComboBox<>(new String[]{"BehaviourTask","HabitTask"});
        JTextField karmaF = new JTextField("10");
        JTextField diffF = new JTextField("1");

        inputs.add(new JLabel("Title:")); inputs.add(titleF);
        inputs.add(new JLabel("Tag:")); inputs.add(tagF);
        inputs.add(new JLabel("Description:")); inputs.add(new JScrollPane(descA));
        inputs.add(new JLabel("Type:")); inputs.add(typeCb);
        inputs.add(new JLabel("Base Karma:")); inputs.add(karmaF);
        inputs.add(new JLabel("Difficulty (for BehaviourTask 1-5):")); inputs.add(diffF);

        right.add(inputs, BorderLayout.NORTH);

        JPanel buttons = new JPanel();
        JButton addBtn = new JButton("Add Task");
        JButton completeBtn = new JButton("Mark Completed");
        JButton deleteBtn = new JButton("Delete");
        buttons.add(addBtn); buttons.add(completeBtn); buttons.add(deleteBtn);
        right.add(buttons, BorderLayout.CENTER);

        JPanel status = new JPanel(new FlowLayout(FlowLayout.LEFT));
        karmaLabel = new JLabel("Total Karma: " + manager.getTotalKarma());
        streakLabel = new JLabel("Tasks: " + manager.getAllTasks().size());
        status.add(karmaLabel); status.add(Box.createHorizontalStrut(20)); status.add(streakLabel);
        right.add(status, BorderLayout.SOUTH);

        // Load existing
        refreshList();

        // Actions
        addBtn.addActionListener(e -> {
            String id = UUID.randomUUID().toString();
            String title = titleF.getText().trim();
            String desc = descA.getText().trim();
            String tag = tagF.getText().trim();
            int base = 10;
            int diff = 1;
            try {
                base = Integer.parseInt(karmaF.getText().trim());
            } catch (Exception ex) {}
            try { diff = Integer.parseInt(diffF.getText().trim()); } catch (Exception ex) {}
            Task t;
            if (typeCb.getSelectedItem().equals("HabitTask")) {
                t = new HabitTask(id, title, desc, base, tag);
            } else {
                t = new BehaviourTask(id, title, desc, base, tag, diff);
            }
            try {
                manager.addTask(t);
                refreshList();
            } catch (TaskValidationException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        completeBtn.addActionListener(e -> {
            String sel = taskList.getSelectedValue();
            if (sel == null) return;
            String id = sel.split(" - ")[0];
            manager.markCompleted(id);
            refreshList();
        });

        deleteBtn.addActionListener(e -> {
            String sel = taskList.getSelectedValue();
            if (sel == null) return;
            String id = sel.split(" - ")[0];
            manager.deleteTask(id);
            refreshList();
        });

        taskList.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if (e.getClickCount()==2) {
                    String sel = taskList.getSelectedValue();
                    if (sel == null) return;
                    String id = sel.split(" - ")[0];
                    Task t = manager.getTask(id);
                    if (t!=null) {
                        JOptionPane.showMessageDialog(MainFrame.this,
                                "Title: "+t.getTitle()+"\nTag: "+t.getTag()+"\nKarma if completed: "+t.calculateKarma()
                                +"\nCompleted: "+t.isCompleted());
                    }
                }
            }
        });
    }

    private void refreshList() {
        listModel.clear();
        List<Task> all = manager.getAllTasks();
        for (Task t : all) {
            String line = t.getId() + " - " + t.getTitle() + " [" + t.getTag() + "] " + (t.isCompleted() ? "(Done)" : "");
            listModel.addElement(line);
        }
        karmaLabel.setText("Total Karma: " + manager.getTotalKarma());
        streakLabel.setText("Tasks: " + all.size());
    }
}
